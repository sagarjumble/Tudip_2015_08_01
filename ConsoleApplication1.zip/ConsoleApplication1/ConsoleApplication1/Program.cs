﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
	class TimeSlot
	{
		public int flag { get; set; }
		public int startHr { get; set; }
		public int endHr { get; set; }
		public int startMin { get; set; }
		public int endMin { get; set; }
	}

	class Program
	{
		static void Main(string[] args)
		{
			Program test = new Program();
			Console.WriteLine("Number of time slot");
			var number = int.Parse(Console.ReadLine());
			Console.WriteLine("Insert " + number + "the time slot in HH:MM fromat");
			var slotList = new List<TimeSlot>();
			while (number != 0)
			{
				TimeSlot time = new TimeSlot();
				Console.WriteLine("Insert starting time");
				var value = Console.ReadLine();
				var div = new string[2];
				if (value.Contains(':'))
				{
					div = value.Split(':');
					if (div[0] == "")
						div[0] = "00";
					if (div[1] == "")
						div[1] = "00";
				}
				else
				{
					if (value == "")
					{
						div[0] = "00";
					}
					else
					{
						div[0] = value;
					}
					div[1] = "00";
				}
				time.startHr = int.Parse(div[0]);
				time.startMin = int.Parse(div[1]);
				Console.WriteLine("Insert ending time");
				value = Console.ReadLine();
				if (value.Contains(':'))
				{
					div = value.Split(':');
					if (div[0] == "")
						div[0] = "00";
					if (div[1] == "")
						div[1] = "00";
				}
				else
				{
					if (value == "")
					{
						div[0] = "00";
					}
					else
					{
						div[0] = value;
					}
					div[1] = "00";
				}
				time.endHr = int.Parse(div[0]);
				time.endMin = int.Parse(div[1]);
				slotList.Add(time);
				number--;
			}
			var sortedDate = test.SortDate(slotList);

			foreach (var list in sortedDate)
			{
				Console.WriteLine(list.startHr + ":" + list.startMin + "  " + list.endHr + ":" + list.endMin);
			}

			Console.ReadKey();
		}


		public List<TimeSlot> SortDate(List<TimeSlot> list)
		{
			var sortedSlot = new List<TimeSlot>();
			foreach (var firstTime in list)
			{
				int flag = 0;
				TimeSlot temp = new TimeSlot();
				if (firstTime.flag == 0)
				{
					foreach (var compairTime in list)
					{
						if (list.IndexOf(firstTime) < list.IndexOf(compairTime))
						{
							if ((firstTime.endHr == compairTime.startHr && firstTime.endMin >= compairTime.startMin) || (firstTime.endHr > compairTime.startHr))
							{
								list.ElementAt(list.IndexOf(compairTime)).flag = 1;
								temp.startHr = firstTime.startHr;
								temp.startMin = firstTime.startMin;
								temp.endHr = compairTime.endHr;
								temp.endMin = compairTime.endMin;
								sortedSlot.Add(temp);
								flag = 1;
								break;
							}

						}
					}
					if (flag == 0)
					{
						sortedSlot.Add(firstTime);
					}
				}
			}
			return sortedSlot;
		}
	}
}

