﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace timeslot
{
	class TimeStruct
	{
		public int startHours { get; set; }
		public int startMinute { get; set; }
		public int endHours { get; set; }
		public int endMinute { get; set; }
	}

	class TimeSlot
	{
		static void Main(string[] args)
		{
			TimeSlot ATS = new TimeSlot();
			Console.WriteLine("Enter number of Time Slots");
			var timeSlot = int.Parse(Console.ReadLine());
			Console.WriteLine("Enter Hours and minutes");

			var TimeSlotList = new List<TimeStruct>();

			for (var count = 0; count < timeSlot; count++)
			{
				TimeStruct time = new TimeStruct();

				Console.WriteLine("Enter Starting hours:");
				time.startHours = int.Parse(Console.ReadLine());

				Console.WriteLine("Enter Starting minutes");
				time.startMinute = int.Parse(Console.ReadLine());

				Console.WriteLine("Enter Ending hours");
				time.endHours = int.Parse(Console.ReadLine());

				Console.WriteLine("Enter Ending minutes");
				time.endMinute = int.Parse(Console.ReadLine());

				TimeSlotList.Add(time);
			}

			ATS.AddTimeSlot(TimeSlotList);
		}

		public void AddTimeSlot(List<TimeStruct> timeSlotList)
		{
			var timeList = timeSlotList;
			var newSlot = new List<TimeStruct>();
			foreach (var currentListTime in timeSlotList)
			{
				var flag = 0;
				TimeStruct t = new TimeStruct();
				foreach (var time in timeList)
				{
					var currentIndex = timeSlotList.IndexOf(currentListTime);
					var tempIndex = timeList.IndexOf(time);
					if (currentIndex < tempIndex)
					{
						if (currentListTime.endHours >= time.startHours)
						{
							t.startHours = currentListTime.startHours;
							t.startMinute = currentListTime.startMinute;
							t.endHours = time.endHours;
							t.endMinute = currentListTime.endMinute;
							newSlot.Add(t);
							flag = 1;
							break;
						}
					}
				}
				if (flag == 0)
				{
					newSlot.Add(currentListTime);
				}
			}

			Console.WriteLine("Start Time\t End Time");
			foreach (var time in newSlot)
			{
				Console.Write(time.startHours + ":" + time.startMinute);
				Console.WriteLine("\t" + time.endHours + ":" + time.endMinute);
				Console.ReadLine();
			}
		}
	}
}